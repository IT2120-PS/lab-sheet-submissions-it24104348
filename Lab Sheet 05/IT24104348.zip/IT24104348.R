setwd("C:\\Users\\RAVIJA'S HP VICTUS\\Desktop\\Ps lab 5")


Delivery_Times <- read.table("Exercise - Lab 05.txt",
                             header = TRUE, sep = "", dec = ".",
                             stringsAsFactors = FALSE)


x <- as.numeric(Delivery_Times$`Delivery_Time_(minutes)`)


breaks_9 <- seq(20, 70, length.out = 10)

# 4) histogram
hist(x,
     breaks = breaks_9,
     right = FALSE,
     include.lowest = TRUE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")

# 5) summary values
mean_x <- mean(x)
median_x <- median(x)
mean_x; median_x
