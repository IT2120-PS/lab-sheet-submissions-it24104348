setwd("C:\\Users\\RAVIJA'S HP VICTUS\\Desktop\\PS lab 4")

branch_data <- read.csv("Exercise.txt", header = TRUE)
boxplot(branch_data$Sales_X1, main="Boxplot of Sales", col="lightblue")

summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)



find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  lower <- Q1 - 1.5 * IQR_value
  upper <- Q3 + 1.5 * IQR_value
  return(x[x < lower | x > upper])
}


find_outliers(branch_data$Years_X3)