setwd("C:\\Users\\Chamith\\Desktop\\PS Lab 6")

# QUESTIONN 1

n <- 50
p <- 0.85
# i) What is the distribution of X? 
cat("Problem 1(i): X ~ Binomial(n =", n, ", p =", p, ")\n\n")

# (ii) Probability that at least 47 students passed:
# P(X >= 47) = 1 - P(X <= 46)
prob_at_least_47 <- 1 - pbinom(46, size = n, prob = p)

cat("Problem 1(ii): P(X >= 47) = ", prob_at_least_47, "\n")
cat("Rounded (4 dp):", format(round(prob_at_least_47, 4), nsmall=4), "\n\n")

 

# Problem 2:
 
lambda <- 12

# (i) Random variable:
cat("Problem 2(i): X = number of calls received in one hour\n\n")

# (ii) Distribution:
cat("Problem 2(ii): X ~ Poisson(lambda =", lambda, ")\n\n")

# (iii) Probability that exactly 15 calls are received:
prob_exact_15 <- dpois(15, lambda = lambda)
cat("Problem 2(iii): P(X = 15) =", prob_exact_15, "\n")
cat("Rounded (4 dp):", format(round(prob_exact_15, 4), nsmall=4), "\n")
